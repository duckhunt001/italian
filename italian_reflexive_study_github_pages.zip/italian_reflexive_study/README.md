# Italian Reflexive Verbs Study

A small, mobile-friendly flashcard app for GitHub Pages. It includes the vocabulary from the supplied notes and schedules reviews using Again / Hard / Good / Easy ratings.

## Publish with GitHub Pages
1. Create a new repository on GitHub (for example, `italian-study`).
2. Upload `index.html` to the repository's root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for GitHub to publish the site. The Pages URL will appear in that section.

## Progress
Review progress is stored in the browser's local storage on the device/browser where you study. It does not automatically sync between devices.

## Vocabulary notes
- `fare colazione` is the usual expression for “to have breakfast.”
- `addormentarsi` means “to fall asleep”; “to go to bed” is `andare a letto`.
